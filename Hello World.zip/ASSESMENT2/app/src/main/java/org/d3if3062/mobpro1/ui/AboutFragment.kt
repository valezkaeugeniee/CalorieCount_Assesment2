package org.d3if3062.mobpro1.ui

import androidx.fragment.app.Fragment
import org.d3if3062.mobpro1.R

class AboutFragment : Fragment(R.layout.fragment_about)