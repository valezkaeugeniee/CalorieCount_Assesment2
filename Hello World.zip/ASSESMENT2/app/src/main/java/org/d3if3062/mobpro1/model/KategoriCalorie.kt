package org.d3if3062.mobpro1.model

enum class KategoriCalorie {
    KEKURANGAN, CUKUP, KELEBIHAN
}