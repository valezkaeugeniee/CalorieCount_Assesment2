package org.d3if3062.mobpro1.model

data class HasilCalorie(val hasil: Float, val kategori: KategoriCalorie) {
}